#!/bin/bash
make -j1 -f buildall