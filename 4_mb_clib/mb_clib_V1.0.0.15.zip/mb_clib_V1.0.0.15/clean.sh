#!/bin/bash
make clean -f buildall